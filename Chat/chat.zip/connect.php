<?php
    $con=mysqli_connect('localhost','root','','signupforms')
    or die("Database Not Connected")
?>